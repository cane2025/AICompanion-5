// lint stub: ensures ESLint pattern "shared/**/*.{js,jsx}" matches at least one file
