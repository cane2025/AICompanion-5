import express, { type Express } from "express";
import fs from "fs";
import path from "path";
import { type Server } from "http";
import { nanoid } from "nanoid";

// ESM-safe __dirname replacement
const __dirname = path.dirname(new URL(import.meta.url).pathname);

export function log(message: string, source = "express") {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });

  console.log(`${formattedTime} [${source}] ${message}`);
}

export async function setupVite(app: Express, server: Server) {
  // import vite and its config dynamically to avoid static ESM resolution in production
  const { createServer: createViteServer, createLogger } = await import("vite");
  const viteLogger = createLogger();
  const { default: viteConfig } = await import("../vite.config");
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true as const,
  };

  const vite = await createViteServer({
    ...viteConfig,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      },
    },
    server: serverOptions,
    appType: "custom",
  });

  app.use(vite.middlewares);
  app.use("*", async (req, res, next) => {
    const url = req.originalUrl;

    try {
      const clientTemplate = path.resolve(
        __dirname,
        "..",
        "client",
        "index.html"
      );

      // always reload the index.html file from disk incase it changes
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      // Comprehensive XSS protection - sanitize URL and template
      const sanitizedUrl = url
        .replace(/[<>\"'&]/g, '') // Remove dangerous characters
        .replace(/javascript:/gi, '') // Remove javascript: protocol
        .replace(/data:/gi, '') // Remove data: protocol
        .replace(/vbscript:/gi, '') // Remove vbscript: protocol
        .substring(0, 1000); // Limit length to prevent buffer overflow
      
      // Additional template sanitization
      const sanitizedTemplate = template
        .replace(/<script[^>]*>.*?<\/script>/gis, '') // Remove script tags
        .replace(/on\w+\s*=/gi, 'data-removed=') // Remove event handlers
        .replace(/javascript:/gi, 'data-removed:') // Remove javascript protocol
        .replace(/data:/gi, 'data-removed:'); // Remove data protocol
      
      const page = await vite.transformIndexHtml(sanitizedUrl, sanitizedTemplate);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e as Error);
      next(e);
    }
  });
}

export function serveStatic(app: Express) {
  // Prefer absolute path from project root (process.cwd())
  let distPath = path.resolve(process.cwd(), "dist", "public");
  if (!fs.existsSync(distPath)) {
    // Fallback to path relative to compiled server file location
    distPath = path.resolve(__dirname, "..", "public");
  }
  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }

  app.use(express.static(distPath));

  // fall through to index.html if the file doesn't exist
  app.use("*", (_req, res) => {
    res.sendFile(path.resolve(distPath, "index.html"));
  });
}
