// lint stub: ensures ESLint pattern "server/**/*.{js,jsx}" matches at least one file
