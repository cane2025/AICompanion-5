#!/bin/bash
echo "Startar utvecklingsservern..."
cd /Users/mirzacelik/Downloads/AICompanion-5
npm run dev
