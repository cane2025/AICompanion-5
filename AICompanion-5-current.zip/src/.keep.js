// placeholder file so eslint pattern src/**/*.{js,jsx} matches at least one file
