// Temporary no-op to satisfy tooling checks. Safe to remove.
process.exit(0);
// TODO: koppla "Ansvarig personal" select → save
// FIXME: byt client.name → client.initials i UI
