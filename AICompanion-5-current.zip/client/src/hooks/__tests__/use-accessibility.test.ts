import { describe, it, expect } from "vitest";

describe("use-accessibility placeholder", () => {
  it("placeholder", () => {
    expect(true).toBe(true);
  });
});
