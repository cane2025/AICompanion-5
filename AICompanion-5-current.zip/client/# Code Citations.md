# Code Citations

## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}

```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
       
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />

```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
       
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div class
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">

```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
         
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <Form
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField

```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
           
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}

```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
           
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"

```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
           
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({ field
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({ field })
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({ field }) =>
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (

```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
             
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <Form
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>

```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
               
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <Form
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Status
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Status</
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Status</Form
```


## License: unknown
https://github.com/mikah13/profile/blob/be2ef678045866580d9f841bfc29caeba110a289/src/app/%28dashboard%29/boards/_components/KanbanBoard.tsx

```
)}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Status</FormLabel
```

